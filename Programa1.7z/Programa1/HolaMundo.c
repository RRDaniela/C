#include <stdio.h>
#include <stdlib.h>

int main(){
    printf("¡Hola Mundo!\n"); //Hola mundo
    system("PAUSE");
    return 0;
}
